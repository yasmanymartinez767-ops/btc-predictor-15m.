# BTC Predictor 15M

Aplicación Streamlit informativa para BTC/USDT. No ejecuta apuestas ni órdenes.

## Despliegue desde Android
1. En GitHub abre tu repositorio y selecciona **Add file → Upload files**.
2. Sube `app.py` y `requirements.txt` a la raíz del repositorio y confirma el commit.
3. Visita https://share.streamlit.io, inicia sesión con GitHub, pulsa **Create app** y selecciona tu repositorio, rama `main` y archivo `app.py`.
4. Pulsa **Deploy**. Abre la URL de la aplicación desde Android y usa **Añadir a pantalla de inicio** desde el menú de Chrome.

## Precauciones
- El bot usa velas públicas BTCUSDT de Binance; pueden existir restricciones geográficas o caídas del servicio.
- Solo muestra sesgo técnico, no probabilidad de acierto calibrada.
- No conecta ni opera en Kalshi.
- El precio de referencia y la hora de liquidación de Kalshi pueden diferir.
- Para medir efectividad, registrar señales en tiempo real y compararlas con precios futuros sin filtración de datos.
